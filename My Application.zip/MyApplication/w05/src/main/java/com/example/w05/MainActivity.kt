package com.example.w05


import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.w05.ui.theme.MyApplicationTheme
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay



@Composable
fun StopwatchScreen() {
    // 1. 상태(State) 관리
    // 시간 (밀리초 단위)
    var elapsedTime by remember { mutableStateOf(0L) }
    // 스톱워치 실행 여부
    var isRunning by remember { mutableStateOf(false) }

    // 2. 시간 카운트 로직 (isRunning 상태가 변경되거나, 이 함수가 실행 중일 때 작동)
    LaunchedEffect(isRunning) {
        while (isRunning) {
            delay(100L) // 0.1초 대기
            elapsedTime += 100L
        }
    }

    // 3. UI 구성
    Scaffold(modifier = Modifier.fillMaxSize()) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // 시간 표시
            Text(
                text = formatTime(elapsedTime),
                fontSize = 80.sp,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // 버튼 레이아웃
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 시작/계속 버튼
                Button(onClick = { isRunning = true }) {
                    Text(text = if (elapsedTime == 0L || !isRunning) "시작" else "계속")
                }

                // 중지 버튼
                Button(onClick = { isRunning = false }, enabled = isRunning) {
                    Text(text = "중지")
                }

                // 재설정 버튼
                Button(onClick = {
                    isRunning = false
                    elapsedTime = 0L
                }) {
                    Text(text = "재설정")
                }
            }
        }
    }
}

// 4. 시간 포맷팅 유틸리티 함수
fun formatTime(timeMillis: Long): String {
    val milliseconds = timeMillis % 1000 / 100 // 100밀리초 단위
    val seconds = (timeMillis / 1000) % 60
    val minutes = (timeMillis / 60000) % 60

    return String.format("%02d:%02d.%d", minutes, seconds, milliseconds)
}

// Preview 함수 (선택 사항)
@Preview(showBackground = true)
@Composable
fun StopwatchPreview() {
    MyApplicationTheme {
        StopwatchScreen()
    }
}
